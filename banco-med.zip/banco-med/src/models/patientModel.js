const db = require("../config/database");
exports.list = () => db.prepare(`SELECT p.*, COALESCE(u.name,'Conta removida') AS created_by_name
  FROM patients p LEFT JOIN users u ON u.id=p.created_by ORDER BY
  CASE p.priority WHEN 'emergencia' THEN 0 WHEN 'muito_urgente' THEN 1 WHEN 'urgente' THEN 2
  WHEN 'pouco_urgente' THEN 3 ELSE 4 END, p.created_at ASC`).all();
exports.find = id => db.prepare(`SELECT p.*, COALESCE(u.name,'Conta removida') AS created_by_name
  FROM patients p LEFT JOIN users u ON u.id=p.created_by WHERE p.id=?`).get(id);
exports.create = data => {
  const result = db.prepare(`INSERT INTO patients(name,age,reason,symptoms,notes,priority,created_by)
    VALUES(@name,@age,@reason,@symptoms,@notes,@priority,@created_by)`).run(data);
  return result.lastInsertRowid;
};
exports.update = (id, fields) => db.prepare(`UPDATE patients SET
  priority=COALESCE(@priority,priority), status=COALESCE(@status,status) WHERE id=@id`).run({...fields,id});
exports.remove = id => db.prepare("DELETE FROM patients WHERE id=?").run(id);
exports.history = id => db.prepare(`SELECT h.*,COALESCE(u.name,'Conta removida') AS user_name
  FROM patient_history h LEFT JOIN users u ON u.id=h.user_id
  WHERE h.patient_id=? ORDER BY h.created_at DESC`).all(id);
exports.addHistory = (patientId,userId,action) => db.prepare(
  "INSERT INTO patient_history(patient_id,user_id,action) VALUES(?,?,?)"
).run(patientId,userId,action);
exports.addLog = (userId,description) => db.prepare(
  "INSERT INTO activity_log(user_id,description) VALUES(?,?)"
).run(userId,description);
exports.getLog = () => db.prepare(`SELECT l.*,COALESCE(u.name,'Sistema') AS user_name
  FROM activity_log l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 300`).all();