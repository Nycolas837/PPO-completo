const db = require("../config/database");
exports.findByRegistration = registration => db.prepare("SELECT * FROM users WHERE registration = ?").get(registration);
exports.findById = id => db.prepare("SELECT id,name,role,registration,active,is_admin,created_at FROM users WHERE id = ?").get(id);
exports.countAdmins = () => db.prepare("SELECT COUNT(*) AS total FROM users WHERE is_admin = 1").get().total;
exports.create = ({ name, role, registration, passwordHash, isAdmin = 0 }) => {
  const result = db.prepare(`INSERT INTO users(name,role,registration,password_hash,is_admin)
    VALUES(?,?,?,?,?)`).run(name, role, registration, passwordHash, isAdmin ? 1 : 0);
  return exports.findById(result.lastInsertRowid);
};
exports.list = () => db.prepare(`SELECT u.id,u.name,u.role,u.registration,u.active,u.created_at,
  (SELECT COUNT(*) FROM patients p WHERE p.created_by=u.id) AS patient_count
  FROM users u WHERE u.is_admin=0 ORDER BY u.name`).all();
exports.setPassword = (id, hash) => db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(hash,id);
exports.setActive = (id, active) => db.prepare("UPDATE users SET active=? WHERE id=? AND is_admin=0").run(active?1:0,id);
exports.remove = id => db.prepare("DELETE FROM users WHERE id=? AND is_admin=0").run(id);