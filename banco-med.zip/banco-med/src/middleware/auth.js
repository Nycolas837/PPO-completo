exports.requireAuth = (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: "Faça login para continuar." });
  next();
};
exports.requireAdmin = (req, res, next) => {
  if (!req.session.user || !req.session.user.isAdmin)
    return res.status(403).json({ error: "Acesso restrito ao administrador." });
  next();
};