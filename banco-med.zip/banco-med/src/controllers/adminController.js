const bcrypt=require("bcryptjs");
const db=require("../config/database");
const User=require("../models/userModel");
const Patient=require("../models/patientModel");
exports.users=(req,res)=>res.json(User.list());
exports.createUser=async(req,res)=>{
  const {name,role,registration,password}=req.body;
  if(!name?.trim()||!registration?.trim()||!password||password.length<6)
    return res.status(400).json({error:"Preencha os campos. A senha deve ter ao menos 6 caracteres."});
  try{
    User.create({name:name.trim(),role,registration:registration.trim(),passwordHash:await bcrypt.hash(password,12)});
    Patient.addLog(req.session.user.id,`Administrador criou a conta ${name.trim()}`);
    res.status(201).json({message:"Conta criada."});
  }catch(e){res.status(409).json({error:"Essa matrícula já está cadastrada."});}
};
exports.toggleUser=(req,res)=>{
  const u=User.findById(Number(req.params.id));
  if(!u||u.is_admin)return res.status(404).json({error:"Conta não encontrada."});
  User.setActive(u.id,!u.active);res.json({message:"Status da conta atualizado."});
};
exports.resetPassword=async(req,res)=>{
  const u=User.findById(Number(req.params.id));
  if(!u||u.is_admin)return res.status(404).json({error:"Conta não encontrada."});
  if(!req.body.password||req.body.password.length<6)return res.status(400).json({error:"A senha deve ter ao menos 6 caracteres."});
  User.setPassword(u.id,await bcrypt.hash(req.body.password,12));res.json({message:"Senha redefinida."});
};
exports.removeUser=(req,res)=>{
  const u=User.findById(Number(req.params.id));
  if(!u||u.is_admin)return res.status(404).json({error:"Conta não encontrada."});
  User.remove(u.id);res.json({message:"Conta excluída."});
};
exports.settings=(req,res)=>res.json({registrationOpen:db.prepare("SELECT value FROM settings WHERE key='registration_open'").get().value==="true"});
exports.updateSettings=(req,res)=>{
  db.prepare("UPDATE settings SET value=? WHERE key='registration_open'").run(req.body.registrationOpen?"true":"false");
  res.json({message:"Configuração salva."});
};
exports.log=(req,res)=>res.json(Patient.getLog());
exports.backup=(req,res)=>{
  const tables={users:db.prepare("SELECT * FROM users").all(),patients:db.prepare("SELECT * FROM patients").all(),
    history:db.prepare("SELECT * FROM patient_history").all(),settings:db.prepare("SELECT * FROM settings").all()};
  res.json(tables);
};

// Visão administrativa somente para leitura das tabelas do SQLite.
exports.databaseOverview=(req,res)=>{
  const definitions=[
    {name:"users",label:"Usuários",query:"SELECT id,name,role,registration,active,is_admin,created_at FROM users ORDER BY id DESC"},
    {name:"patients",label:"Pacientes",query:"SELECT id,name,age,reason,symptoms,notes,priority,status,created_by,created_at FROM patients ORDER BY id DESC"},
    {name:"patient_history",label:"Histórico dos pacientes",query:"SELECT id,patient_id,user_id,action,created_at FROM patient_history ORDER BY id DESC"},
    {name:"activity_log",label:"Registro de atividades",query:"SELECT id,user_id,description,created_at FROM activity_log ORDER BY id DESC"},
    {name:"settings",label:"Configurações",query:"SELECT key,value FROM settings ORDER BY key"}
  ];
  const tables=definitions.map(t=>({
    name:t.name,
    label:t.label,
    columns:db.prepare(`PRAGMA table_info(${t.name})`).all().map(c=>({name:c.name,type:c.type,primaryKey:Boolean(c.pk)})),
    rows:db.prepare(t.query).all(),
    count:db.prepare(`SELECT COUNT(*) AS total FROM ${t.name}`).get().total
  }));
  res.json({database:"banco-med.sqlite",tables});
};
