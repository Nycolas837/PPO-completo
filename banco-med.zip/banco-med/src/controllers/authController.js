const bcrypt = require("bcryptjs");
const User = require("../models/userModel");
const db = require("../config/database");
const log = require("../models/patientModel").addLog;

exports.status = (req,res) => res.json({
  user: req.session.user || null,
  adminExists: User.countAdmins() > 0,
  registrationOpen: db.prepare("SELECT value FROM settings WHERE key='registration_open'").get().value === "true"
});
exports.setupAdmin = async (req,res) => {
  if (User.countAdmins()) return res.status(409).json({error:"Administrador já configurado."});
  const {name="Administrador",registration,password} = req.body;
  if (!registration || !password || password.length < 8) return res.status(400).json({error:"Informe matrícula e senha com ao menos 8 caracteres."});
  try {
    const user=User.create({name,role:"Administrador",registration,passwordHash:await bcrypt.hash(password,12),isAdmin:1});
    req.session.user={id:user.id,name:user.name,registration:user.registration,role:user.role,isAdmin:true};
    log(user.id,"Administrador configurado");
    res.status(201).json({user:req.session.user});
  } catch(e) { res.status(400).json({error:"Matrícula já cadastrada."}); }
};
exports.register = async (req,res) => {
  const open=db.prepare("SELECT value FROM settings WHERE key='registration_open'").get().value==="true";
  if (!open) return res.status(403).json({error:"O cadastro está fechado pelo administrador."});
  const {name,role,registration,password}=req.body;
  if (!name?.trim() || !registration?.trim() || !password || password.length<6)
    return res.status(400).json({error:"Preencha os campos. A senha deve ter ao menos 6 caracteres."});
  try {
    User.create({name:name.trim(),role,registration:registration.trim(),passwordHash:await bcrypt.hash(password,12)});
    res.status(201).json({message:"Conta criada. Faça login."});
  } catch(e) { res.status(409).json({error:"Essa matrícula já está cadastrada."}); }
};
exports.login = async (req,res) => {
  const {registration,password}=req.body;
  const user=User.findByRegistration(String(registration||"").trim());
  if (!user || !await bcrypt.compare(password||"",user.password_hash))
    return res.status(401).json({error:"Matrícula ou senha incorretas."});
  if (!user.active) return res.status(403).json({error:"Conta desativada. Procure o administrador."});
  req.session.user={id:user.id,name:user.name,registration:user.registration,role:user.role,isAdmin:!!user.is_admin};
  log(user.id,`${user.name} entrou`);
  res.json({user:req.session.user});
};
exports.logout = (req,res) => {
  if(req.session.user) log(req.session.user.id,`${req.session.user.name} saiu`);
  req.session.destroy(()=>res.json({message:"Sessão encerrada."}));
};
exports.changePassword = async (req,res) => {
  const {currentPassword,newPassword}=req.body;
  const raw=require("../config/database").prepare("SELECT password_hash FROM users WHERE id=?").get(req.session.user.id);
  if(!await bcrypt.compare(currentPassword||"",raw.password_hash)) return res.status(400).json({error:"Senha atual incorreta."});
  if(!newPassword || newPassword.length<6) return res.status(400).json({error:"A nova senha deve ter ao menos 6 caracteres."});
  require("../config/database").prepare("UPDATE users SET password_hash=? WHERE id=?").run(await bcrypt.hash(newPassword,12),req.session.user.id);
  res.json({message:"Senha alterada com sucesso."});
};