const Patient=require("../models/patientModel");
const priorities=["emergencia","muito_urgente","urgente","pouco_urgente","nao_urgente"];
const statuses=["aguardando","atendimento","finalizado"];
exports.list=(req,res)=>res.json(Patient.list());
exports.get=(req,res)=>{
  const patient=Patient.find(Number(req.params.id));
  if(!patient)return res.status(404).json({error:"Paciente não encontrado."});
  res.json({...patient,history:Patient.history(patient.id)});
};
exports.create=(req,res)=>{
  const {name,age,reason,symptoms="",notes="",priority="urgente"}=req.body;
  if(!name?.trim()||!reason?.trim()||!priorities.includes(priority))return res.status(400).json({error:"Nome, motivo e prioridade válida são obrigatórios."});
  const id=Patient.create({name:name.trim(),age:age===""?null:Number(age)||null,reason:reason.trim(),symptoms,notes,priority,created_by:req.session.user.id});
  Patient.addHistory(id,req.session.user.id,"Paciente cadastrado na fila");
  Patient.addLog(req.session.user.id,`${req.session.user.name} cadastrou ${name.trim()}`);
  res.status(201).json(Patient.find(id));
};
exports.update=(req,res)=>{
  const id=Number(req.params.id),p=Patient.find(id);
  if(!p)return res.status(404).json({error:"Paciente não encontrado."});
  const {priority,status}=req.body;
  if(priority&&!priorities.includes(priority))return res.status(400).json({error:"Prioridade inválida."});
  if(status&&!statuses.includes(status))return res.status(400).json({error:"Status inválido."});
  Patient.update(id,{priority:priority||null,status:status||null});
  if(priority&&priority!==p.priority)Patient.addHistory(id,req.session.user.id,`Prioridade alterada para ${priority}`);
  if(status&&status!==p.status)Patient.addHistory(id,req.session.user.id,`Status alterado para ${status}`);
  Patient.addLog(req.session.user.id,`Atualizou o paciente ${p.name}`);
  res.json({...Patient.find(id),history:Patient.history(id)});
};
exports.addAction=(req,res)=>{
  const p=Patient.find(Number(req.params.id));
  if(!p)return res.status(404).json({error:"Paciente não encontrado."});
  if(!req.body.action?.trim())return res.status(400).json({error:"Escreva a ação."});
  Patient.addHistory(p.id,req.session.user.id,req.body.action.trim());
  res.status(201).json(Patient.history(p.id));
};
exports.remove=(req,res)=>{
  const p=Patient.find(Number(req.params.id));
  if(!p)return res.status(404).json({error:"Paciente não encontrado."});
  Patient.remove(p.id);Patient.addLog(req.session.user.id,`Excluiu o paciente ${p.name}`);
  res.json({message:"Paciente excluído."});
};