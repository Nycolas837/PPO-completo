(() => {
"use strict";
const $=s=>document.querySelector(s);
const app=$("#app");
const priorities=[
 {id:"emergencia",label:"Emergência",time:"Risco iminente",color:"#d83d4b"},
 {id:"muito_urgente",label:"Muito urgente",time:"Até 10 min",color:"#e77a32"},
 {id:"urgente",label:"Urgente",time:"Até 60 min",color:"#c69b19"},
 {id:"pouco_urgente",label:"Pouco urgente",time:"Até 120 min",color:"#168c7c"},
 {id:"nao_urgente",label:"Não urgente",time:"Até 240 min",color:"#397fa7"}
];
const statusLabels={aguardando:"Aguardando",atendimento:"Em atendimento",finalizado:"Finalizado"};
const roles=["Médico(a)","Enfermeiro(a)","Técnico(a) de enfermagem","Recepção","Outro"];
let state={user:null,adminExists:true,registrationOpen:true,mode:"login",tab:"professional",error:"",patients:[],selected:null,users:[],log:[],settings:{},database:[]};
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const priority=id=>priorities.find(p=>p.id===id)||priorities[2];
const date=v=>new Date(v+"Z").toLocaleString("pt-BR",{dateStyle:"short",timeStyle:"short"});
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),2800)}
function fail(err){toast(err.message||"Ocorreu um erro.");}
async function refresh(){state.patients=await API.get("/patients");}
function auth(){
 const admin=state.tab==="admin";let content="";
 if(admin&&!state.adminExists)content=`<h2>Configurar administrador</h2><p class="sub">Crie a conta principal para administrar o sistema.</p>
 <form id="setup"><label class="field">Matrícula<input name="registration" required></label><label class="field">Senha (mínimo 8 caracteres)<input name="password" type="password" minlength="8" required></label><button class="btn full">Criar administrador</button></form>`;
 else if(admin)content=`<h2>Acesso administrativo</h2><p class="sub">Entre com a matrícula e senha do administrador.</p><form id="login"><label class="field">Matrícula<input name="registration" required></label><label class="field">Senha<input name="password" type="password" required></label><button class="btn full">Entrar</button></form>`;
 else if(state.mode==="register")content=`<h2>Criar conta profissional</h2><p class="sub">Cadastre o acesso da equipe de saúde.</p><form id="register"><label class="field">Nome completo<input name="name" required></label><label class="field">Cargo<select name="role">${roles.map(x=>`<option>${x}</option>`).join("")}</select></label><label class="field">Matrícula<input name="registration" required></label><label class="field">Senha (mínimo 6 caracteres)<input name="password" type="password" minlength="6" required></label><button class="btn full">Criar conta</button></form><div class="switch-line">Já possui acesso? <button class="text-button" data-action="mode" data-value="login">Entrar</button></div>`;
 else content=`<h2>Bem-vindo de volta</h2><p class="sub">Acesse a fila e os prontuários do Banco Med.</p><form id="login"><label class="field">Matrícula<input name="registration" required autocomplete="username"></label><label class="field">Senha<input name="password" type="password" required autocomplete="current-password"></label><button class="btn full">Entrar no sistema</button></form>${state.registrationOpen?`<div class="switch-line">Ainda não possui conta? <button class="text-button" data-action="mode" data-value="register">Criar conta</button></div>`:""}`;
 return `<div class="auth"><section class="auth-hero"><div class="brand-mark"><span class="brand-icon">✚</span> Banco Med</div><div><h1>Cuidado organizado começa com informação clara.</h1><p>Fila de atendimento e prontuários em um só lugar, com prioridade visual e histórico de ações da equipe.</p></div><div class="hero-bottom"><div class="priority-line">${priorities.map(p=>`<i style="background:${p.color}"></i>`).join("")}</div><p>Gestão de atendimento hospitalar</p></div></section><section class="auth-content"><div class="auth-box"><div class="tabs"><button class="${admin?"":"active"}" data-action="tab" data-value="professional">Profissional</button><button class="${admin?"active":""}" data-action="tab" data-value="admin">Administrador</button></div>${state.error?`<div class="message">${esc(state.error)}</div>`:""}${content}</div></section></div>`;
}
function nav(v,label,count){return `<button class="nav ${state.view===v?"active":""}" data-action="view" data-value="${v}">${label}${count!==undefined?`<span class="nav-count">${count}</span>`:""}</button>`}
function shell(body){
 const admin=state.user.isAdmin,active=state.patients.filter(p=>p.status!=="finalizado").length;
 return `<div class="layout"><aside class="sidebar"><div class="brand"><div class="brand-mark"><span class="brand-icon">✚</span> Banco Med</div><small>${admin?"Painel administrativo":"Gestão hospitalar"}</small></div><div class="nav-title">Menu principal</div>${admin?nav("users","Contas",state.users.length)+nav("patients","Pacientes",state.patients.length)+nav("activity","Atividade")+nav("database","Banco de dados")+nav("settings","Configurações"):nav("queue","Fila de pacientes",active)+nav("new","Novo paciente")+nav("done","Atendidos",state.patients.length-active)+nav("account","Minha conta")}<div class="profile"><strong>${esc(state.user.name)}</strong><span>${admin?"Administrador":esc(state.user.role)+" · "+esc(state.user.registration)}</span><button class="btn secondary small" data-action="logout">Sair da conta</button></div></aside><main class="main">${body}</main></div>${state.selected?drawer():""}`;
}
function header(title,desc,button=""){return `<div class="page-head"><div><h2>${title}</h2><p>${desc}</p></div>${button}</div>`}
function queue(done=false){
 const list=state.patients.filter(p=>(p.status==="finalizado")===done);
 const counts=priorities.map(p=>({...p,count:list.filter(x=>x.priority===p.id).length}));
 return `${header(done?"Pacientes atendidos":"Fila de pacientes",done?"Atendimentos finalizados.":"Acompanhe os pacientes por grau de prioridade.",!done?`<button class="btn" data-action="view" data-value="new">+ Novo paciente</button>`:"")}
 <section class="stats">${counts.map(p=>`<button class="stat" style="--accent:${p.color}" data-action="filter" data-value="${p.id}"><strong>${p.count}</strong><span>${p.label}</span></button>`).join("")}</section>
 <div class="toolbar"><input class="search" id="search" placeholder="Buscar paciente por nome ou motivo..."><button class="btn secondary small" data-action="clear-filter">Limpar filtros</button></div>
 <div class="list" id="patient-list">${patientRows(list)}</div>`;
}
function patientRows(list){
 const q=($("#search")?.value||"").toLowerCase();
 const filtered=list.filter(p=>(!state.filter||p.priority===state.filter)&&(!q||(p.name+" "+p.reason).toLowerCase().includes(q)));
 if(!filtered.length)return `<div class="empty">Nenhum paciente encontrado com esses filtros.</div>`;
 return filtered.map(p=>{const pr=priority(p.priority);return `<button class="patient" style="--accent:${pr.color}" data-action="open" data-id="${p.id}"><span class="patient-name">${esc(p.name)}${p.age?` · ${p.age} anos`:""}<span class="status ${p.status}">${statusLabels[p.status]}</span></span><span class="patient-meta">${esc(p.reason)}</span><span class="patient-right"><span class="priority" style="--accent:${pr.color}">${pr.label}</span><span>${esc(p.created_by_name)} · ${date(p.created_at)}</span></span></button>`}).join("");
}
function newPatient(){return `${header("Cadastrar paciente","Registre os dados e defina a prioridade de atendimento.")}<section class="card"><form id="new-patient"><div class="grid2"><label class="field">Nome do paciente<input name="name" required></label><label class="field">Idade<input name="age" type="number" min="0" max="130"></label></div><label class="field">Motivo da consulta<input name="reason" required></label><label class="field">Sintomas<textarea name="symptoms"></textarea></label><label class="field">Observações / histórico clínico<textarea name="notes"></textarea></label><div class="field">Grau de prioridade<div class="priority-options">${priorities.map(p=>`<label style="--accent:${p.color}"><input type="radio" name="priority" value="${p.id}" ${p.id==="urgente"?"checked":""}><span>${p.label}</span></label>`).join("")}</div></div><div class="actions"><button type="button" class="btn secondary" data-action="view" data-value="queue">Cancelar</button><button class="btn">Adicionar à fila</button></div></form></section>`}
function drawer(){
 const p=state.selected,pr=priority(p.priority);
 return `<div class="overlay" data-action="close-overlay"><aside class="drawer"><div class="drawer-head"><span class="priority" style="--accent:${pr.color}">${pr.label}</span><button class="btn secondary small" data-action="close">Fechar</button></div><h3>${esc(p.name)}${p.age?`, ${p.age} anos`:""}</h3><div class="actions">${p.status==="aguardando"?`<button class="btn" data-action="status" data-value="atendimento">Iniciar atendimento</button>`:p.status==="atendimento"?`<button class="btn" data-action="status" data-value="finalizado">Finalizar atendimento</button><button class="btn secondary" data-action="status" data-value="aguardando">Voltar à fila</button>`:`<button class="btn secondary" data-action="status" data-value="aguardando">Reabrir</button>`}</div><div class="detail"><small>Status</small>${statusLabels[p.status]}</div><div class="detail"><small>Motivo</small>${esc(p.reason)}</div><div class="detail"><small>Sintomas</small>${esc(p.symptoms)||"—"}</div><div class="detail"><small>Observações</small>${esc(p.notes)||"—"}</div><div class="detail"><small>Registrado por</small>${esc(p.created_by_name)} · ${date(p.created_at)}</div><div class="section-label">Alterar prioridade</div><select id="priority-change">${priorities.map(x=>`<option value="${x.id}" ${x.id===p.priority?"selected":""}>${x.label} · ${x.time}</option>`).join("")}</select><div class="section-label">Histórico de ações</div>${(p.history||[]).map(h=>`<div class="history-item"><small>${esc(h.user_name)} · ${date(h.created_at)}</small>${esc(h.action)}</div>`).join("")||`<div class="empty">Nenhuma ação registrada.</div>`}<form id="add-action" class="toolbar" style="margin-top:15px"><input class="search" name="action" placeholder="Registrar ação ou atualização..." required><button class="btn">Adicionar</button></form><button class="btn danger" style="margin-top:25px" data-action="delete-patient" data-id="${p.id}">Excluir paciente</button></aside></div>`;
}
function adminUsers(){return `${header("Contas de profissionais","Gerencie os acessos da equipe.")}<div class="card"><h3>Criar conta</h3><form id="admin-create"><div class="grid2"><label class="field">Nome completo<input name="name" required></label><label class="field">Cargo<select name="role">${roles.map(r=>`<option>${r}</option>`).join("")}</select></label><label class="field">Matrícula<input name="registration" required></label><label class="field">Senha inicial<input name="password" type="password" minlength="6" required></label></div><button class="btn">Criar conta</button></form></div><div class="table-wrap"><table><thead><tr><th>Nome</th><th>Cargo</th><th>Matrícula</th><th>Pacientes</th><th>Status</th><th>Ações</th></tr></thead><tbody>${state.users.map(u=>`<tr><td>${esc(u.name)}</td><td>${esc(u.role)}</td><td>${esc(u.registration)}</td><td>${u.patient_count}</td><td>${u.active?"Ativa":"Desativada"}</td><td><div class="actions"><button class="btn secondary small" data-action="toggle-user" data-id="${u.id}">${u.active?"Desativar":"Ativar"}</button><button class="btn secondary small" data-action="reset-user" data-id="${u.id}">Redefinir senha</button><button class="btn danger small" data-action="remove-user" data-id="${u.id}">Excluir</button></div></td></tr>`).join("")||`<tr><td colspan="6">Nenhuma conta cadastrada.</td></tr>`}</tbody></table></div>`}
function adminPatients(){return `${header("Todos os pacientes","Visão administrativa de todos os prontuários.")}<div class="table-wrap"><table><thead><tr><th>Paciente</th><th>Prioridade</th><th>Status</th><th>Motivo</th><th>Registrado por</th></tr></thead><tbody>${state.patients.map(p=>`<tr class="clickable" data-action="open" data-id="${p.id}"><td>${esc(p.name)}</td><td>${priority(p.priority).label}</td><td>${statusLabels[p.status]}</td><td>${esc(p.reason)}</td><td>${esc(p.created_by_name)}</td></tr>`).join("")||`<tr><td colspan="5">Nenhum paciente.</td></tr>`}</tbody></table></div>`}
function settings(){return `${header("Configurações","Controle de cadastro e cópia dos dados.")}<section class="card"><h3>Cadastro de profissionais</h3><label><input type="checkbox" id="registration-open" ${state.settings.registrationOpen?"checked":""}> Permitir criação de novas contas na tela inicial</label></section><section class="card"><h3>Backup do banco de dados</h3><p class="muted">Baixe uma cópia dos dados para arquivamento. O arquivo contém informações sensíveis de pacientes.</p><button class="btn secondary" data-action="backup">Baixar backup JSON</button></section><section class="card"><h3>Alterar senha do administrador</h3><form id="change-password"><label class="field">Senha atual<input type="password" name="currentPassword" required></label><label class="field">Nova senha<input type="password" name="newPassword" minlength="6" required></label><button class="btn">Salvar nova senha</button></form></section>`}
function activity(){return `${header("Atividade do sistema","Registros recentes de acesso e alterações.")}<div class="table-wrap"><table><thead><tr><th>Data</th><th>Usuário</th><th>Atividade</th></tr></thead><tbody>${state.log.map(l=>`<tr><td>${date(l.created_at)}</td><td>${esc(l.user_name)}</td><td>${esc(l.description)}</td></tr>`).join("")||`<tr><td colspan="3">Sem atividade registrada.</td></tr>`}</tbody></table></div>`}
function databaseView(){
 return `${header("Banco de dados","Visualização em texto das tabelas armazenadas no SQLite.")}<div class="database-note"><strong>Modo de consulta</strong><span>Esta tela permite visualizar os registros. Senhas e hashes de autenticação são ocultados e nenhuma informação pode ser alterada por aqui.</span></div>${state.database.map(t=>`<section class="db-card"><div class="db-card-head"><div><h3>${esc(t.label)}</h3><code>${esc(t.name)}</code></div><span class="db-count">${t.count} registro(s)</span></div><div class="table-wrap"><table><thead><tr>${t.columns.map(c=>`<th>${esc(c.name)}<small class="db-type">${esc(c.type||"TEXT")}${c.primaryKey?" · PK":""}</small></th>`).join("")}</tr></thead><tbody>${t.rows.map(row=>`<tr>${t.columns.map(c=>`<td>${esc(row[c.name]===null?"NULL":row[c.name]===undefined?"":String(row[c.name]))}</td>`).join("")}</tr>`).join("")||`<tr><td colspan="${Math.max(t.columns.length,1)}">Nenhum registro nesta tabela.</td></tr>`}</tbody></table></div></section>`).join("")}<p class="muted db-footnote">Para consultar o arquivo físico, ele continua salvo em <code>data/banco-med.sqlite</code>.</p>`
}
function account(){return `${header("Minha conta","Dados de acesso e segurança.")}<section class="card"><h3>${esc(state.user.name)}</h3><p class="muted">${esc(state.user.role)} · Matrícula ${esc(state.user.registration)}</p><form id="change-password"><label class="field">Senha atual<input type="password" name="currentPassword" required></label><div class="grid2"><label class="field">Nova senha<input type="password" name="newPassword" minlength="6" required></label></div><button class="btn">Alterar senha</button></form></section>`}
async function render(){
 if(!state.user){app.innerHTML=auth();return}
 try{
  await refresh();
  let body;
  if(state.user.isAdmin){
   if(state.view==="users"){state.users=await API.get("/admin/users");body=adminUsers()}
   else if(state.view==="patients")body=adminPatients();
   else if(state.view==="activity"){state.log=await API.get("/admin/log");body=activity()}
   else if(state.view==="database"){const data=await API.get("/admin/database");state.database=data.tables;body=databaseView()}
   else if(state.view==="settings"){state.settings=await API.get("/admin/settings");body=settings()}
   else{state.view="users";state.users=await API.get("/admin/users");body=adminUsers()}
  }else{
   body=state.view==="new"?newPatient():state.view==="account"?account():queue(state.view==="done");
  }
  app.innerHTML=shell(body);
 }catch(e){fail(e)}
}
function formData(form){return Object.fromEntries(new FormData(form).entries())}
async function initialize(){
 try{
  const s=await API.get("/auth/status");state.user=s.user;state.adminExists=s.adminExists;state.registrationOpen=s.registrationOpen;
  if(state.user)state.view=state.user.isAdmin?"users":"queue";
  render();
 }catch(e){app.innerHTML=`<div class="empty">Não foi possível conectar ao servidor. Verifique se o Banco Med está iniciado.</div>`}
}
app.addEventListener("click",async e=>{
 const el=e.target.closest("[data-action]");if(!el)return;
 const action=el.dataset.action,value=el.dataset.value,id=el.dataset.id;
 try{
  if(action==="tab"){state.tab=value;state.error=""}
  if(action==="mode"){state.mode=value;state.error=""}
  if(action==="view"){state.view=value;state.filter=""}
  if(action==="open"){state.selected=await API.get("/patients/"+id)}
  if(action==="close"){state.selected=null}
  if(action==="close-overlay"&&e.target===el){state.selected=null}
  if(action==="logout"){await API.post("/auth/logout",{});state.user=null;state.selected=null;state.tab="professional";state.mode="login"}
  if(action==="filter"){state.filter=state.filter===value?"":value}
  if(action==="clear-filter"){state.filter=""}
  if(action==="status"){await API.patch("/patients/"+state.selected.id,{status:value});state.selected=await API.get("/patients/"+state.selected.id);toast("Status atualizado.")}
  if(action==="delete-patient"){if(!confirm("Excluir este paciente e seu histórico?"))return;await API.delete("/patients/"+id);state.selected=null;toast("Paciente excluído.")}
  if(action==="toggle-user"){await API.patch("/admin/users/"+id+"/toggle",{});toast("Conta atualizada.")}
  if(action==="reset-user"){const password=prompt("Digite a nova senha (mínimo 6 caracteres):");if(password===null)return;await API.post("/admin/users/"+id+"/password",{password});toast("Senha redefinida.")}
  if(action==="remove-user"){if(!confirm("Excluir esta conta?"))return;await API.delete("/admin/users/"+id);toast("Conta excluída.")}
  if(action==="backup"){const data=await API.get("/admin/backup");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download="banco-med-backup.json";a.click();URL.revokeObjectURL(a.href)}
  await render();
 }catch(err){fail(err)}
});
app.addEventListener("submit",async e=>{
 const form=e.target;if(!form.matches("form"))return;e.preventDefault();const d=formData(form);
 try{
  if(form.id==="setup"){const r=await API.post("/auth/setup",d);state.user=r.user;state.view="users"}
  if(form.id==="login"){const r=await API.post("/auth/login",d);state.user=r.user;state.view=state.user.isAdmin?"users":"queue"}
  if(form.id==="register"){await API.post("/auth/register",d);state.mode="login";toast("Conta criada. Faça login.")}
  if(form.id==="new-patient"){await API.post("/patients",d);state.view="queue";toast("Paciente adicionado à fila.")}
  if(form.id==="add-action"){await API.post("/patients/"+state.selected.id+"/history",d);state.selected=await API.get("/patients/"+state.selected.id);toast("Ação registrada.")}
  if(form.id==="admin-create"){await API.post("/admin/users",d);toast("Conta criada.")}
  if(form.id==="change-password"){await API.post("/auth/password",d);toast("Senha alterada com sucesso.")}
  await render();
 }catch(err){if(!state.user){state.error=err.message;render()}else fail(err)}
});
app.addEventListener("change",async e=>{
 try{
  if(e.target.id==="priority-change"&&state.selected){await API.patch("/patients/"+state.selected.id,{priority:e.target.value});state.selected=await API.get("/patients/"+state.selected.id);render()}
  if(e.target.id==="registration-open"){await API.put("/admin/settings",{registrationOpen:e.target.checked});state.settings.registrationOpen=e.target.checked;toast("Configuração salva.")}
 }catch(err){fail(err)}
});
app.addEventListener("input",e=>{
 if(e.target.id==="search"){const done=state.view==="done";$("#patient-list").innerHTML=patientRows(state.patients.filter(p=>(p.status==="finalizado")===done))}
});
state.filter="";
initialize();
})();