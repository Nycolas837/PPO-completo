window.API = {
  async request(url, options={}) {
    const config={credentials:"same-origin",...options,headers:{"Content-Type":"application/json",...(options.headers||{})}};
    const response=await fetch("/api"+url,config);
    const data=await response.json().catch(()=>({}));
    if(!response.ok) throw new Error(data.error||"Não foi possível concluir a operação.");
    return data;
  },
  get(url){return this.request(url)},
  post(url,body){return this.request(url,{method:"POST",body:JSON.stringify(body)})},
  patch(url,body){return this.request(url,{method:"PATCH",body:JSON.stringify(body)})},
  put(url,body){return this.request(url,{method:"PUT",body:JSON.stringify(body)})},
  delete(url){return this.request(url,{method:"DELETE"})}
};