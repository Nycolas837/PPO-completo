# Banco Med

Sistema de fila hospitalar e prontuários com Node.js, Express e SQLite.

## Requisitos
- Node.js 18 ou superior
- npm

## Instalação
1. Extraia a pasta do projeto.
2. Abra o terminal dentro da pasta `banco-med`.
3. Execute:

```bash
npm install
npm start
```

4. Acesse `http://localhost:3000`.
5. No primeiro acesso, selecione **Administrador** e crie a conta principal.

## Estrutura

```text
banco-med/
├── data/                    # Banco SQLite e sessões (criado automaticamente)
├── public/
│   ├── css/styles.css       # Estilos
│   ├── js/api.js            # Comunicação HTTP com a API
│   ├── js/app.js            # Interface e eventos do navegador
│   └── index.html
├── src/
│   ├── config/database.js   # Conexão e criação das tabelas SQLite
│   ├── controllers/         # Regras das funcionalidades
│   ├── middleware/          # Autenticação e autorização
│   ├── models/               # Consultas ao banco de dados
│   └── routes/               # Endpoints da API
├── server.js
└── package.json
```

## Funcionalidades
- Cadastro e login de profissionais por matrícula.
- Primeiro acesso para criação do administrador.
- Senhas armazenadas com hash bcrypt.
- Fila de pacientes ordenada por prioridade.
- Cadastro de pacientes, sintomas e observações.
- Histórico de ações por paciente.
- Mudança de prioridade e status do atendimento.
- Painel administrativo para contas, pacientes, atividade e configurações.
- Ativação/desativação de contas e redefinição de senha.
- Backup JSON dos dados.

## Observações importantes
- O arquivo `data/banco-med.sqlite` é criado automaticamente na primeira execução.
- O sistema usa sessões armazenadas em SQLite.
- Para uso real em hospital, é necessário HTTPS, segredo de sessão forte via variável `SESSION_SECRET`, controle de acesso por perfil, política de backup, auditoria e adequação à LGPD. Este projeto é uma base acadêmica/de desenvolvimento e não deve ser usado com dados reais de pacientes sem avaliação de segurança e validação profissional.
- O cadastro administrativo de profissionais usa o mesmo endpoint de cadastro público, portanto o administrador deve manter o cadastro aberto para criar novas contas nesta versão.


## Visualizador do banco de dados

Administradores podem abrir a opção **Banco de dados** no menu lateral para consultar, em tabelas legíveis, a estrutura e os registros do SQLite. A rota `/api/admin/database` exige sessão administrativa e é somente de leitura. O campo `password_hash` não é exposto nessa visualização.
